import torch
from flwr.client import ClientApp, NumPyClient
from flwr.common import Context
from loguru import logger
from sklearn.metrics import confusion_matrix

from fl_diabetes_prediction.task import (
    Net,
    evaluate,
    get_weights,
    load_flwr_data,
    set_weights,
    train,
)


class FlowerClient(NumPyClient):
    def __init__(self, net, trainloader, testloader):
        print("\n" + "=" * 80)
        print("🔵 FLOWER CLIENT INITIALIZED")
        print(
            f"   Training samples: {len(trainloader.dataset)} ({len(trainloader)} batches) | "
            f"Test samples: {len(testloader.dataset)} ({len(testloader)} batches)"
        )
        print("=" * 80 + "\n")
        self.net = net
        self.trainloader = trainloader
        self.testloader = testloader

    def fit(self, parameters, config):
        print("\n" + "▶" * 80)
        print("🟢 TRAINING ROUND STARTED")
        print(f"   Samples: {len(self.trainloader.dataset)} ({len(self.trainloader)} batches)")
        print("▶" * 80)
        set_weights(self.net, parameters)
        train(self.net, self.trainloader)
        print("✅ TRAINING COMPLETE\n")
        return get_weights(self.net), len(self.trainloader.dataset), {}

    def evaluate(self, parameters, config):
        print("\n" + "◆" * 80)
        print("🔵 EVALUATION ROUND STARTED")
        print(f"   Samples: {len(self.testloader.dataset)} ({len(self.testloader)} batches)")
        print("◆" * 80)
        set_weights(self.net, parameters)
        loss, accuracy = evaluate(self.net, self.testloader)

        # Calcula matriz de confusão localmente no Data Owner (sem expor dados brutos)
        self.net.eval()
        device = next(self.net.parameters()).device
        y_true, y_pred = [], []
        with torch.no_grad():
            for batch in self.testloader:
                inputs, labels = batch[0].to(device), batch[1].to(device)
                outputs = self.net(inputs)
                if outputs.shape[-1] == 1:
                    preds = (torch.sigmoid(outputs).squeeze(-1) >= 0.5).long()
                else:
                    preds = torch.argmax(outputs, dim=1)
                y_true.extend(labels.cpu().numpy().tolist())
                y_pred.extend(preds.cpu().numpy().tolist())

        tn, fp, fn, tp = confusion_matrix(y_true, y_pred, labels=[0, 1]).ravel()

        print("📊 EVALUATION RESULTS:")
        print(f"   Loss: {loss:.4f} | Accuracy: {accuracy:.4f} | CM: [[{tn}, {fp}], [{fn}, {tp}]]")
        print("✅ EVALUATION COMPLETE\n")
        return (
            float(loss),
            len(self.testloader.dataset),
            {
                "accuracy": float(accuracy),
                "loss": float(loss),
                "tn": int(tn),
                "fp": int(fp),
                "fn": int(fn),
                "tp": int(tp),
            },
        )


def client_fn(context: Context):
    print("\n" + "█" * 80)
    print("🚀 CLIENT FUNCTION STARTED")
    print(f"📋 Node Config: {context.node_config}")
    print("█" * 80 + "\n")
    from fl_diabetes_prediction.task import load_syftbox_dataset
    from syft_flwr.utils import run_syft_flwr

    if not run_syft_flwr():
        print("📦 Loading Flower data locally...")
        logger.info("Running flwr locally")
        train_loader, test_loader = load_flwr_data(
            partition_id=context.node_config["partition-id"],
            num_partitions=context.node_config["num-partitions"],
        )
    else:
        print("📦 Loading SyftBox dataset...")
        logger.info("Running with syft_flwr")
        train_loader, test_loader = load_syftbox_dataset()
    net = Net()
    return FlowerClient(net, train_loader, test_loader).to_client()


app = ClientApp(client_fn=client_fn)