"""fltabular: Flower Example on Adult Census Income Tabular Dataset."""

iimport json
import os
from pathlib import Path
from typing import Callable, List, Tuple

import numpy as np
from flwr.common import Context, Metrics, ndarrays_to_parameters
from flwr.server import ServerApp, ServerAppComponents, ServerConfig
from syft_flwr.strategy import FedAvgWithModelSaving

from fl_diabetes_prediction.task import Net, get_weights


def make_weighted_average(
    metrics_file: Path,
) -> Callable[[List[Tuple[int, Metrics]]], Metrics]:
    """Cria a função de agregação ponderada com registro de histórico em disco."""
    history_log = []

    def weighted_average(metrics: List[Tuple[int, Metrics]]) -> Metrics:
        print("\n" + "⚖" * 80)
        print("📊 AGGREGATING METRICS")
        print(f"   Number of clients: {len(metrics)}")
        print("⚖" * 80)

        examples = [num_examples for num_examples, _ in metrics]
        total_examples = sum(examples)

        raw_accuracies = [float(m["accuracy"]) for _, m in metrics]
        avg_accuracy = (
            sum(n * acc for n, acc in zip(examples, raw_accuracies)) / total_examples
            if total_examples > 0
            else 0.0
        )

        round_data = {
            "round": len(history_log) + 1,
            "num_clients": len(metrics),
            "global_accuracy": float(avg_accuracy),
            "min_accuracy": float(np.min(raw_accuracies)),
            "max_accuracy": float(np.max(raw_accuracies)),
            "std_accuracy": float(np.std(raw_accuracies)),
        }

        # Registra perda agregada caso os clientes enviem o escalar "loss"
        if all("loss" in m for _, m in metrics):
            raw_losses = [float(m["loss"]) for _, m in metrics]
            avg_loss = (
                sum(n * loss for n, loss in zip(examples, raw_losses)) / total_examples
                if total_examples > 0
                else 0.0
            )
            round_data["global_loss"] = float(avg_loss)
            round_data["min_loss"] = float(np.min(raw_losses))
            round_data["max_loss"] = float(np.max(raw_losses))

        history_log.append(round_data)

        # Persiste o histórico agregado a cada rodada (sem dados brutos ou IDs de clientes)
        metrics_file.parent.mkdir(parents=True, exist_ok=True)
        metrics_file.write_text(
            json.dumps(history_log, indent=2), encoding="utf-8"
        )

        print(
            f"✅ AGGREGATION COMPLETE - Average Accuracy: {avg_accuracy:.4f} "
            f"(min={round_data['min_accuracy']:.4f}, max={round_data['max_accuracy']:.4f}, "
            f"std={round_data['std_accuracy']:.4f})"
        )
        print(f"💾 Metrics saved to: {metrics_file}\n")

        return {
            "accuracy": round_data["global_accuracy"],
            "min_accuracy": round_data["min_accuracy"],
            "max_accuracy": round_data["max_accuracy"],
            "std_accuracy": round_data["std_accuracy"],
        }

    return weighted_average


def server_fn(context: Context) -> ServerAppComponents:
    print("\n" + "█" * 80)
    print("🚀 SERVER FUNCTION STARTED")
    print(f"📋 Run Config: {context.run_config}")
    print("█" * 80 + "\n")

    net = Net()
    params = ndarrays_to_parameters(get_weights(net))

    # Always use RDS job output directory
    output_dir = os.getenv("OUTPUT_DIR")
    if output_dir is None:
        output_dir = Path(__file__).parent.parent.parent / "outputs"
    output_dir = Path(output_dir)
    output_dir.mkdir(parents=True, exist_ok=True)

    save_path = output_dir / "weights"
    metrics_file = output_dir / "metrics_history.json"
    if metrics_file.exists():
        metrics_file.unlink()

    # Fault tolerance configuration
    # With 4 total clients, system can tolerate 50% failure (2 clients)
    # and still have 2 clients for training
    min_available_clients = context.run_config.get("min-available-clients", 1)
    min_fit_clients = context.run_config.get("min-fit-clients", 1)
    min_evaluate_clients = context.run_config.get("min-evaluate-clients", 1)
    fraction_fit = context.run_config.get("fraction-fit", 1)
    fraction_evaluate = context.run_config.get("fraction-evaluate", 1)

    print("⚙️ CONFIGURING STRATEGY")
    print("   Strategy: FedAvgWithModelSaving")
    print(f"   Model save path: {save_path}")
    print(f"   Metrics history path: {metrics_file}")
    print(f"   Min available clients: {min_available_clients}")
    print(f"   Min fit clients: {min_fit_clients}")
    print(f"   Min evaluate clients: {min_evaluate_clients}")
    print(f"   Fraction fit: {fraction_fit}")
    print(f"   Fraction evaluate: {fraction_evaluate}")

    strategy = FedAvgWithModelSaving(
        save_path=save_path,
        fraction_fit=fraction_fit,
        fraction_evaluate=fraction_evaluate,
        min_available_clients=min_available_clients,
        min_fit_clients=min_fit_clients,
        min_evaluate_clients=min_evaluate_clients,
        initial_parameters=params,
        evaluate_metrics_aggregation_fn=make_weighted_average(metrics_file),
    )
    num_rounds = context.run_config["num-server-rounds"]
    print(f"   Number of rounds: {num_rounds}\n")
    config = ServerConfig(num_rounds=num_rounds)

    print("✅ SERVER INITIALIZATION COMPLETE\n")
    return ServerAppComponents(config=config, strategy=strategy)


app = ServerApp(server_fn=server_fn)